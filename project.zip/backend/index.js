/**
 * NOVA AI — Secure Serverless Backend Proxy
 * Compatible with Cloudflare Workers (100% Free, 100,000 requests/day, no credit card required)
 * and Node.js / Express / Firebase Cloud Functions.
 */

export default {
  async fetch(request, env) {
    // Enable CORS for Android client requests
    const corsHeaders = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS, GET",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders });
    }

    const url = new URL(request.url);

    // Health check endpoint
    if (url.pathname === "/" || url.pathname === "/health") {
      return new Response(
        JSON.stringify({ status: "online", service: "NOVA AI Secure Backend", timestamp: Date.now() }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (request.method !== "POST") {
      return new Response(JSON.stringify({ error: "Only POST requests are allowed" }), {
        status: 405,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    try {
      // 1. Validate Secret API Key
      const apiKey = env.GEMINI_API_KEY || (typeof process !== "undefined" && process.env.GEMINI_API_KEY);
      if (!apiKey) {
        return new Response(
          JSON.stringify({
            error: "Backend Configuration Error: GEMINI_API_KEY is not set in backend environment secrets.",
            status: "error"
          }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // 2. Parse and Validate Request Payload
      const body = await request.json();
      const userMessage = body.message;
      if (!userMessage || typeof userMessage !== "string" || userMessage.trim().length === 0) {
        return new Response(
          JSON.stringify({ error: "Invalid request: 'message' string field is required." }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Request Size & Rate Limiting Check
      if (userMessage.length > 4000) {
        return new Response(
          JSON.stringify({ error: "Request payload too large. Maximum message length is 4000 characters." }),
          { status: 413, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const model = body.model || "gemini-1.5-flash";
      const language = body.language || "bn";
      const clientHistory = Array.isArray(body.history) ? body.history : [];

      // 3. Build Gemini API Request with Persona & Guardrails
      const systemPrompt =
        "You are NOVA AI, a futuristic, friendly, and ultra-capable personal Android AI agent. " +
        "You are fully bilingual in Bengali (বাংলা) and English. When addressed in Bengali, respond in fluent, conversational Bengali. " +
        "You assist with device automation, gaming advice (such as Free Fire), coding, problem solving, reminders, and daily life questions. " +
        "Keep your answers crisp, well-formatted, helpful, and polite.";

      const contents = [
        {
          role: "user",
          parts: [{ text: `System Instruction: ${systemPrompt}` }]
        },
        {
          role: "model",
          parts: [{ text: "Understood. I am NOVA AI, ready to assist you." }]
        }
      ];

      // Add last few turns of conversation history
      for (const item of clientHistory.slice(-6)) {
        if (item.text && item.role) {
          contents.push({
            role: item.role === "user" ? "user" : "model",
            parts: [{ text: item.text }]
          });
        }
      }

      // Append current user message
      contents.push({
        role: "user",
        parts: [{ text: userMessage }]
      });

      // 4. Call Google Gemini API securely
      const geminiEndpoint = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

      const geminiResponse = await fetch(geminiEndpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents,
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 2048,
          }
        })
      });

      if (!geminiResponse.ok) {
        const errorText = await geminiResponse.text();
        return new Response(
          JSON.stringify({
            error: `Gemini API responded with status ${geminiResponse.status}`,
            details: errorText
          }),
          { status: geminiResponse.status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const data = await geminiResponse.json();
      const reply =
        data.candidates?.[0]?.content?.parts?.[0]?.text ||
        "দুঃখিত, কোনো উত্তর পাওয়া যায়নি।";

      // 5. Return sanitized response to Android Client
      return new Response(
        JSON.stringify({
          status: "success",
          reply: reply.trim(),
          model: model,
          timestamp: Date.now()
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    } catch (err) {
      return new Response(
        JSON.stringify({ error: "Internal Server Error", message: err.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
  }
};
