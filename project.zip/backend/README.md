# 🌐 NOVA AI — Secure Serverless Backend Guide (সম্পূর্ণ বাংলা নির্দেশিকা)

এই ব্যাকএন্ডটি আপনার Google Gemini API Key-কে নিরাপদে সার্ভারে সংরক্ষণ করে। ফলে আপনার Android APK বা GitHub Repository-তে কখনোই গোপন API Key উন্মুক্ত হয় না।

---

## 💰 কেন Cloudflare Workers? (১০০% ফ্রি)
- **বিনামূল্যে সুবিধা:** প্রতিদিন **১,০০,০০০ (এক লাখ) রিকোয়েস্ট সম্পূর্ণ ফ্রি**।
- **কোনো ক্রেডিট কার্ড লাগে না:** সম্পূর্ণ বিনামূল্যে একাউন্ট খোলা যায়।
- **অতি দ্রুত রেসপন্স:** গ্লোবাল এজ নেটওয়ার্ক থেকে দ্রুত উত্তর পাঠায়।
- বিকল্প: Firebase Cloud Functions-এও deploy করা যায় (তবে Firebase Blaze Plan-এ কার্ড চাইতে পারে, তাই Cloudflare Workers সবচেয়ে উত্তম ও নিরাপদ)।

---

## 🔑 ধাপ ১: Google AI Studio থেকে ফ্রি API Key সংগ্রহ
1. আপনার ব্রাউজার থেকে যান: [https://aistudio.google.com/app/apikey](https://aistudio.google.com/app/apikey)
2. আপনার গুগল একাউন্ট দিয়ে লগইন করুন।
3. **"Create API key"** বোতামে চাপ দিন।
4. তৈরি হওয়া API Key-টি কপি করে নিরাপদ স্থানে সংরক্ষণ করুন।

---

## 🚀 ধাপ ২: ব্রাউজার থেকে ২ মিনিটে Cloudflare Worker ডিপ্লয় (মোবাইল থেকেই সম্ভব!)
1. ব্রাউজার থেকে [https://dash.cloudflare.com/sign-up](https://dash.cloudflare.com/sign-up)-এ গিয়ে ফ্রি একাউন্ট খুলুন।
2. ড্যাশবোর্ডের বাম পাশের মেনু থেকে **"Workers & Pages"**-এ যান।
3. **"Create application"** > **"Create Worker"** নির্বাচন করুন।
4. নাম দিন: `nova-ai-backend` এবং **"Deploy"** চাপুন।
5. এবার **"Edit code"** বাটনে চাপ দিন।
6. এডিটরের সব কোড মুছে এই প্রজেক্টের `backend/index.js`-এর সম্পূর্ণ কোডটি পেস্ট করুন।
7. উপরে ডানদিকের **"Save and Deploy"** চাপুন।

---

## 🔐 ধাপ ৩: সিক্রেট API Key যুক্ত করা
1. আপনার তৈরি করা Worker-এর ড্যাশবোর্ডে যান।
2. **"Settings"** ট্যাবে ক্লিক করুন।
3. **"Variables and Secrets"** সেকশনে যান।
4. **"Add"** ক্লিক করুন:
   - Variable name: `GEMINI_API_KEY`
   - Type: **"Secret"** (বা "Encrypt")
   - Value: আপনার ধাপ ১ থেকে পাওয়া Gemini API Key
5. **"Save and deploy"** চাপুন।

---

## 📱 ধাপ ৪: NOVA AI Android অ্যাপের সাথে যুক্ত করা
1. আপনার Worker-এর URL কপি করুন (যেমন: `https://nova-ai-backend.yourname.workers.dev/api/chat` বা `https://nova-ai-backend.yourname.workers.dev/`)
2. আপনার Android মোবাইলে **NOVA AI** অ্যাপ খুলুন।
3. নিচে **"সেটিংস" (Settings)** ট্যাবে যান।
4. **"নিরাপদ Backend Proxy URL"** ঘরে আপনার Worker URL পেস্ট করুন।
5. **"সংযোগ পরীক্ষা করুন"** বোতাম চাপুন।
6. "সংযুক্ত হয়েছে! সফল উত্তর পাওয়া গেছে ✅" দেখালে আপনার সেটআপ ১০০% সম্পন্ন!
