package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.tools.CommandResult
import com.example.tools.PhoneToolsManager
import com.example.tools.VoiceCommander
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class VoiceCommanderTest {

    private lateinit var commander: VoiceCommander

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val toolsManager = PhoneToolsManager(context)
        commander = VoiceCommander(toolsManager)
    }

    @Test
    fun testBatteryCommand() {
        val result = commander.processCommand("ব্যাটারি কত")
        assertTrue(result is CommandResult.Executed)
    }

    @Test
    fun testAiFallback() {
        val result = commander.processCommand("মহাবিশ্বের বয়স কত?")
        assertTrue(result is CommandResult.SendToAi)
    }
}
