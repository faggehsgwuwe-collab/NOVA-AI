package com.example

import android.app.Application
import android.content.Intent
import android.os.Build
import android.speech.tts.TextToSpeech
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ChatMessage
import com.example.service.AutoTalkService
import com.example.service.FloatingWindowService
import com.example.service.NovaAccessibilityService
import com.example.tools.CommandResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class MainViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private val app = application as NovaApp
    private val chatDao = app.database.chatDao()
    private val phoneTools = app.phoneTools
    private val voiceCommander = app.voiceCommander
    private val geminiClient = app.geminiApiClient
    val preferences = app.preferences

    val messages: StateFlow<List<ChatMessage>> = chatDao.getAllMessages()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isThinking = MutableStateFlow(false)
    val isThinking = _isThinking.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening = _isListening.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking = _isSpeaking.asStateFlow()

    private val _batteryText = MutableStateFlow(phoneTools.getBatteryInfo())
    val batteryText = _batteryText.asStateFlow()

    private val _networkText = MutableStateFlow(phoneTools.getNetworkInfo())
    val networkText = _networkText.asStateFlow()

    private val _isFlashlightOn = MutableStateFlow(phoneTools.isFlashlightActive())
    val isFlashlightOn = _isFlashlightOn.asStateFlow()

    private val _isFloatingRunning = MutableStateFlow(FloatingWindowService.isRunning)
    val isFloatingRunning = _isFloatingRunning.asStateFlow()

    private val _isAutoTalkRunning = MutableStateFlow(AutoTalkService.isRunning)
    val isAutoTalkRunning = _isAutoTalkRunning.asStateFlow()

    private val _isAccessibilityEnabled = MutableStateFlow(NovaAccessibilityService.isServiceRunning(app))
    val isAccessibilityEnabled = _isAccessibilityEnabled.asStateFlow()

    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    init {
        tts = TextToSpeech(application, this)
        refreshStatus()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            updateTtsLanguage()
        }
    }

    fun updateTtsLanguage() {
        if (!isTtsReady) return
        val lang = if (preferences.language == "bn") Locale("bn", "BD") else Locale.US
        tts?.language = lang
        tts?.setPitch(preferences.ttsPitch)
        tts?.setSpeechRate(preferences.ttsSpeed)
    }

    fun refreshStatus() {
        _batteryText.value = phoneTools.getBatteryInfo()
        _networkText.value = phoneTools.getNetworkInfo()
        _isFlashlightOn.value = phoneTools.isFlashlightActive()
        _isFloatingRunning.value = FloatingWindowService.isRunning
        _isAutoTalkRunning.value = AutoTalkService.isRunning
        _isAccessibilityEnabled.value = NovaAccessibilityService.isServiceRunning(app)
    }

    fun toggleFlashlight() {
        val newState = phoneTools.toggleFlashlight()
        _isFlashlightOn.value = newState
    }

    fun handleUserMessage(input: String, isVoice: Boolean = false) {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return

        viewModelScope.launch {
            // Save user message to database
            val userMsg = ChatMessage(sender = "user", text = trimmed, isVoice = isVoice)
            chatDao.insertMessage(userMsg)

            // Step 1: Process device commands
            val result = voiceCommander.processCommand(trimmed)
            when (result) {
                is CommandResult.Executed -> {
                    chatDao.insertMessage(ChatMessage(sender = "nova", text = result.message))
                    speak(result.message)
                    refreshStatus()
                }
                is CommandResult.SendToAi -> {
                    _isThinking.value = true
                    val recent = withContext(Dispatchers.IO) { chatDao.getRecentMessages(6) }
                    val aiResponse = geminiClient.sendMessage(trimmed, recent)
                    _isThinking.value = false

                    val replyText = aiResponse.getOrElse {
                        "দুঃখিত, উত্তর তৈরিতে সমস্যা হয়েছে: ${it.localizedMessage ?: "নেটওয়ার্ক বা কনফিগারেশন ত্রুটি"}"
                    }

                    chatDao.insertMessage(
                        ChatMessage(
                            sender = "nova",
                            text = replyText,
                            isError = aiResponse.isFailure
                        )
                    )
                    speak(replyText)
                }
            }
        }
    }

    fun speak(text: String) {
        if (!preferences.isTtsEnabled || !isTtsReady) return
        _isSpeaking.value = true
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nova_tts_${System.currentTimeMillis()}")
    }

    fun stopSpeaking() {
        tts?.stop()
        _isSpeaking.value = false
    }

    fun setListening(listening: Boolean) {
        _isListening.value = listening
    }

    fun clearChat() {
        viewModelScope.launch {
            chatDao.clearHistory()
        }
    }

    fun toggleFloatingService(): Boolean {
        return if (FloatingWindowService.isRunning) {
            val stopIntent = Intent(app, FloatingWindowService::class.java).apply {
                action = FloatingWindowService.ACTION_STOP
            }
            app.startService(stopIntent)
            _isFloatingRunning.value = false
            false
        } else {
            val startIntent = Intent(app, FloatingWindowService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                app.startForegroundService(startIntent)
            } else {
                app.startService(startIntent)
            }
            _isFloatingRunning.value = true
            true
        }
    }

    fun toggleAutoTalkService(): Boolean {
        return if (AutoTalkService.isRunning) {
            val stopIntent = Intent(app, AutoTalkService::class.java).apply {
                action = AutoTalkService.ACTION_STOP
            }
            app.startService(stopIntent)
            _isAutoTalkRunning.value = false
            false
        } else {
            val startIntent = Intent(app, AutoTalkService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                app.startForegroundService(startIntent)
            } else {
                app.startService(startIntent)
            }
            _isAutoTalkRunning.value = true
            true
        }
    }

    override fun onCleared() {
        super.onCleared()
        tts?.stop()
        tts?.shutdown()
    }
}
