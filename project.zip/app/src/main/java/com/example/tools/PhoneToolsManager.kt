package com.example.tools

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings
import com.example.receiver.ReminderReceiver

class PhoneToolsManager(private val context: Context) {

    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
    private var isTorchOn = false

    fun toggleFlashlight(forceState: Boolean? = null): Boolean {
        try {
            val cameraManager = this.cameraManager ?: return false
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                val chars = cameraManager.getCameraCharacteristics(id)
                chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return false

            val newState = forceState ?: !isTorchOn
            cameraManager.setTorchMode(cameraId, newState)
            isTorchOn = newState
            return isTorchOn
        } catch (e: CameraAccessException) {
            return false
        } catch (e: Exception) {
            return false
        }
    }

    fun isFlashlightActive(): Boolean = isTorchOn

    fun getBatteryInfo(): String {
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val batteryPct = batteryManager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        val isCharging = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val status = batteryManager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS)
            status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        } else {
            false
        }

        return if (batteryPct >= 0) {
            "ব্যাটারি চার্জ: $batteryPct% ${if (isCharging) "⚡ (চার্জ হচ্ছে)" else ""}"
        } else {
            "ব্যাটারি তথ্য পাওয়া যায়নি"
        }
    }

    fun getNetworkInfo(): String {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return "ইন্টারনেট অবস্থা অজানা"

        val activeNetwork = cm.activeNetwork ?: return "ইন্টারনেট সংযোগ নেই ❌"
        val caps = cm.getNetworkCapabilities(activeNetwork) ?: return "ইন্টারনেট সংযোগ নেই ❌"

        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "সংযুক্ত: Wi-Fi নেটওয়ার্ক 📶"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "সংযুক্ত: মোবাইল ডাটা 📶"
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) -> "ইন্টারনেট সক্রিয় ✅"
            else -> "ইন্টারনেট সংযোগ বিচ্ছিন্ন ❌"
        }
    }

    fun openWifiSettings(): Boolean {
        return try {
            val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun openBluetoothSettings(): Boolean {
        return try {
            val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun openAccessibilitySettings(): Boolean {
        return try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun openOverlaySettings(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${context.packageName}")
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                true
            } else {
                true
            }
        } catch (e: Exception) {
            false
        }
    }

    fun launchAppByName(query: String): String {
        val pm = context.packageManager
        val cleanQuery = query.lowercase().trim()

        // Known common mappings
        val knownPackages = mapOf(
            "free fire" to listOf("com.dts.freefireth", "com.dts.freefiremax"),
            "whatsapp" to listOf("com.whatsapp", "com.whatsapp.w4b"),
            "youtube" to listOf("com.google.android.youtube"),
            "facebook" to listOf("com.facebook.katana"),
            "messenger" to listOf("com.facebook.orca"),
            "tiktok" to listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill"),
            "instagram" to listOf("com.instagram.android"),
            "telegram" to listOf("org.telegram.messenger")
        )

        for ((key, pkgList) in knownPackages) {
            if (cleanQuery.contains(key)) {
                for (pkg in pkgList) {
                    val intent = pm.getLaunchIntentForPackage(pkg)
                    if (intent != null) {
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(intent)
                        return "চালু করা হচ্ছে: $key"
                    }
                }
                return "$key আপনার ফোনে ইনস্টল করা নেই!"
            }
        }

        // Generic search through installed apps
        val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        for (app in installedApps) {
            val appLabel = pm.getApplicationLabel(app).toString().lowercase()
            if (appLabel.contains(cleanQuery) || cleanQuery.contains(appLabel)) {
                val intent = pm.getLaunchIntentForPackage(app.packageName)
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    val originalLabel = pm.getApplicationLabel(app).toString()
                    return "চালু করা হচ্ছে: $originalLabel"
                }
            }
        }

        return "অ্যাপটি খুঁজে পাওয়া যায়নি: $query"
    }

    fun scheduleReminder(reminderText: String, delayMinutes: Int): Boolean {
        return try {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
                ?: return false

            val intent = Intent(context, ReminderReceiver::class.java).apply {
                putExtra(ReminderReceiver.EXTRA_MESSAGE, reminderText)
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                System.currentTimeMillis().toInt(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val triggerTime = System.currentTimeMillis() + (delayMinutes * 60 * 1000L)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
            } else {
                alarmManager.set(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
