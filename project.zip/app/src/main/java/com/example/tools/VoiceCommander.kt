package com.example.tools

import java.util.regex.Pattern

sealed class CommandResult {
    data class Executed(val message: String) : CommandResult()
    data object SendToAi : CommandResult()
}

class VoiceCommander(private val toolsManager: PhoneToolsManager) {

    fun processCommand(input: String): CommandResult {
        val text = input.trim().lowercase()

        // Flashlight ON
        if (containsAny(text, "flashlight চালু", "লাইট জ্বালাও", "ফ্ল্যাশলাইট চালু", "ফ্লাশলাইট জ্বালাও", "turn on flashlight", "flashlight on")) {
            val state = toolsManager.toggleFlashlight(forceState = true)
            return CommandResult.Executed(if (state) "ফ্ল্যাশলাইট চালু করা হয়েছে! 💡" else "ফ্ল্যাশলাইট চালু করা সম্ভব হয়নি।")
        }

        // Flashlight OFF
        if (containsAny(text, "flashlight বন্ধ", "লাইট নিভাও", "ফ্ল্যাশলাইট বন্ধ", "ফ্লাশলাইট বন্ধ", "turn off flashlight", "flashlight off")) {
            toolsManager.toggleFlashlight(forceState = false)
            return CommandResult.Executed("ফ্ল্যাশলাইট বন্ধ করা হয়েছে। 🌑")
        }

        // Flashlight TOGGLE
        if (containsAny(text, "ফ্ল্যাশলাইট", "ফ্লাশলাইট", "flashlight", "টর্চ")) {
            if (containsAny(text, "অন", "চালু", "জ্বালাও")) {
                val state = toolsManager.toggleFlashlight(forceState = true)
                return CommandResult.Executed(if (state) "ফ্ল্যাশলাইট চালু করা হয়েছে! 💡" else "ফ্ল্যাশলাইট পাওয়া যায়নি।")
            } else if (containsAny(text, "অফ", "বন্ধ", "নিভাও")) {
                toolsManager.toggleFlashlight(forceState = false)
                return CommandResult.Executed("ফ্ল্যাশলাইট বন্ধ করা হয়েছে। 🌑")
            }
        }

        // Battery
        if (containsAny(text, "ব্যাটারি", "চার্জ কত", "battery", "charge percentage")) {
            return CommandResult.Executed(toolsManager.getBatteryInfo())
        }

        // Internet / Network
        if (containsAny(text, "ইন্টারনেট", "নেটওয়ার্ক", "wifi", "internet status", "connection")) {
            return CommandResult.Executed(toolsManager.getNetworkInfo())
        }

        // Free Fire
        if (containsAny(text, "free fire", "ফ্রি ফায়ার")) {
            val res = toolsManager.launchAppByName("free fire")
            return CommandResult.Executed(res)
        }

        // WhatsApp
        if (containsAny(text, "whatsapp", "হোয়াটসঅ্যাপ", "হোয়াটসঅ্যাপ")) {
            val res = toolsManager.launchAppByName("whatsapp")
            return CommandResult.Executed(res)
        }

        // YouTube
        if (containsAny(text, "youtube", "ইউটিউব")) {
            val res = toolsManager.launchAppByName("youtube")
            return CommandResult.Executed(res)
        }

        // Wi-Fi Settings
        if (containsAny(text, "ওয়াইফাই সেটিংস", "ওয়াই-ফাই সেটিংস", "wifi settings")) {
            toolsManager.openWifiSettings()
            return CommandResult.Executed("Wi-Fi সেটিংস খোলা হচ্ছে...")
        }

        // Bluetooth Settings
        if (containsAny(text, "ব্লুটুথ সেটিংস", "bluetooth settings")) {
            toolsManager.openBluetoothSettings()
            return CommandResult.Executed("Bluetooth সেটিংস খোলা হচ্ছে...")
        }

        // Reminder parsing e.g. "মনে করিয়ে দাও ১০ মিনিট পর ওষুধ খাওয়া" or "remind me in 15 minutes to take medicine"
        if (containsAny(text, "মনে করিয়ে দাও", "রিমাইন্ডার", "remind me")) {
            val minutes = extractMinutes(text) ?: 10
            val cleanText = text.replace("মনে করিয়ে দাও", "")
                .replace("রিমাইন্ডার", "")
                .replace("remind me", "")
                .trim()
            val reminderContent = if (cleanText.isEmpty()) "নির্ধারিত কাজ সম্পূর্ণ করুন" else cleanText
            val ok = toolsManager.scheduleReminder(reminderContent, minutes)
            return if (ok) {
                CommandResult.Executed("ঠিক আছে, $minutes মিনিট পরে আপনাকে রিমাইন্ডার দেব: \"$reminderContent\" ⏰")
            } else {
                CommandResult.Executed("রিমাইন্ডার সেট করা যায়নি।")
            }
        }

        // Open app commands: "খোল", "খোলো", "চালু করো", "open"
        if (text.startsWith("open ") || text.endsWith(" খোলো") || text.endsWith(" চালু করো") || text.endsWith(" open")) {
            val appQuery = text.replace("open", "")
                .replace("খোলো", "")
                .replace("চালু করো", "")
                .trim()
            if (appQuery.isNotEmpty()) {
                val res = toolsManager.launchAppByName(appQuery)
                return CommandResult.Executed(res)
            }
        }

        return CommandResult.SendToAi
    }

    private fun containsAny(text: String, vararg targets: String): Boolean {
        for (target in targets) {
            if (text.contains(target, ignoreCase = true)) return true
        }
        return false
    }

    private fun extractMinutes(text: String): Int? {
        val pattern = Pattern.compile("(\\d+)\\s*(মিনিট|min|minute)")
        val matcher = pattern.matcher(text)
        if (matcher.find()) {
            return matcher.group(1)?.toIntOrNull()
        }
        return null
    }
}
