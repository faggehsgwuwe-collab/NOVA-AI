package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// NOVA AI Futuristic Cyberpunk Palette
val DeepNavy = Color(0xFF070B14)
val DarkNavyBg = Color(0xFF0B101D)
val SurfaceNavy = Color(0xFF111827)
val CardNavy = Color(0xFF162032)
val CardNavyBorder = Color(0xFF1E293B)

val NeonCyan = Color(0xFF00E5FF)
val NeonCyanGlow = Color(0x3300E5FF)
val ElectricBlue = Color(0xFF00B0FF)
val NeonPurple = Color(0xFFA855F7)
val NeonPurpleGlow = Color(0x33A855F7)
val DeepViolet = Color(0xFF7C3AED)
val NeonPink = Color(0xFFF43F5E)
val NeonGreen = Color(0xFF10B981)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val UserBubbleBg = Color(0xFF2E1065)
val AiBubbleBg = Color(0xFF0F172A)
val AiBubbleBorder = Color(0xFF1E293B)
