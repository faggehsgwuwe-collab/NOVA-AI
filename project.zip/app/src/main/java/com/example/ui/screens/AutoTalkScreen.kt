package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.MainViewModel
import com.example.NovaApp
import com.example.ui.components.GlowingOrb
import com.example.ui.components.NeonCard
import com.example.ui.theme.CardNavy
import com.example.ui.theme.CardNavyBorder
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun AutoTalkScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isAutoTalkRunning by viewModel.isAutoTalkRunning.collectAsStateWithLifecycle()
    val prefs = NovaApp.instance.preferences

    var selectedInterval by remember { mutableIntStateOf(prefs.autoTalkIntervalMinutes) }
    val scrollState = rememberScrollState()

    val intervals = listOf(5, 10, 15, 30, 60)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DeepNavy)
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        GlowingOrb(size = 80.dp, isSpeakingOrThinking = isAutoTalkRunning)

        Text(
            text = "🗣️ অটোমেটিক ভয়েস কনভার্সেশন",
            color = NeonCyan,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = "নির্দিষ্ট বিরতিতে NOVA AI স্বপ্রণোদিত হয়ে আপনার সঙ্গে কথা বলবে, কাজের খোঁজ নেবে অথবা প্রয়োজনীয় টিপস ও রিমাইন্ডার দেবে।",
            color = TextSecondary,
            fontSize = 13.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            lineHeight = 18.sp
        )

        // Status Card
        NeonCard(borderColor = if (isAutoTalkRunning) NeonGreen.copy(alpha = 0.5f) else CardNavyBorder) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.RecordVoiceOver,
                        contentDescription = null,
                        tint = if (isAutoTalkRunning) NeonGreen else TextMuted
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Auto Talk স্ট্যাটাস",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isAutoTalkRunning) NeonGreen.copy(alpha = 0.2f) else CardNavyBorder)
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isAutoTalkRunning) "সক্রিয় ($selectedInterval মিনিট)" else "নিষ্ক্রিয়",
                        color = if (isAutoTalkRunning) NeonGreen else TextMuted,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Interval Selector Card
        NeonCard(borderColor = NeonPurple.copy(alpha = 0.4f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Timer, contentDescription = null, tint = NeonPurple, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "কথা বলার সময় বিরতি (Interval)",
                    color = NeonPurple,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                intervals.forEach { interval ->
                    val isSelected = selectedInterval == interval
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) NeonPurple else CardNavy)
                            .border(
                                1.dp,
                                if (isSelected) NeonPurple else CardNavyBorder,
                                RoundedCornerShape(10.dp)
                            )
                            .clickable {
                                selectedInterval = interval
                                prefs.autoTalkIntervalMinutes = interval
                                if (isAutoTalkRunning) {
                                    // Restart service to pick up new interval
                                    viewModel.toggleAutoTalkService()
                                    viewModel.toggleAutoTalkService()
                                }
                            }
                            .padding(vertical = 12.dp)
                            .testTag("interval_${interval}_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "$interval মিঃ",
                            color = if (isSelected) Color.White else TextPrimary,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Master Start / Stop Button
        Button(
            onClick = {
                val ok = viewModel.toggleAutoTalkService()
                Toast.makeText(
                    context,
                    if (ok) "Auto-Talk চালু করা হয়েছে ($selectedInterval মিনিট অন্তর) 🗣️" else "Auto-Talk বন্ধ করা হয়েছে 🛑",
                    Toast.LENGTH_SHORT
                ).show()
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isAutoTalkRunning) NeonPink else NeonCyan
            ),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("auto_talk_toggle_btn")
        ) {
            Icon(
                imageVector = if (isAutoTalkRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                contentDescription = null,
                tint = if (isAutoTalkRunning) Color.White else DeepNavy
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isAutoTalkRunning) "Auto-Talk বন্ধ করুন" else "Auto-Talk শুরু করুন",
                color = if (isAutoTalkRunning) Color.White else DeepNavy,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        }

        // Android Background Execution Notice
        NeonCard(borderColor = ElectricBlue.copy(alpha = 0.3f)) {
            Row(verticalAlignment = Alignment.Top) {
                Icon(Icons.Default.Info, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "অ্যান্ড্রয়েড ব্যাকগ্রাউন্ড পলিসি ও ব্যাটারি গাইড",
                        color = ElectricBlue,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "• Android-এর ব্যাটারি অপ্টিমাইজেশনের কারণে ব্যাকগ্রাউন্ডে সার্ভিস যাতে বন্ধ না হয়, সেজন্য এটি Foreground Service নোটিফিকেশনের মাধ্যমে পরিচালিত হয়।\n• নোটিফিকেশনে সরাসরি 'বন্ধ করুন' বোতাম রয়েছে।\n• ডিভাইস লক থাকলেও নোটিফিকেশনে মেসেজ প্রদর্শিত হবে এবং স্পিকারে কথা শোনা যাবে।",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 17.sp
                    )
                }
            }
        }
    }
}
