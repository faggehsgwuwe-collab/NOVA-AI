package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPurple

@Composable
fun GlowingOrb(
    modifier: Modifier = Modifier,
    size: Dp = 100.dp,
    isSpeakingOrThinking: Boolean = false
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_pulse")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = if (isSpeakingOrThinking) 1.25f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isSpeakingOrThinking) 800 else 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isSpeakingOrThinking) 3000 else 7000),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val center = this.center
            val baseRadius = this.size.minDimension / 2.5f

            // Outer glowing aura
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(NeonCyan.copy(alpha = 0.35f), NeonPurple.copy(alpha = 0.15f), Color.Transparent),
                    center = center,
                    radius = baseRadius * pulseScale * 1.3f
                ),
                radius = baseRadius * pulseScale * 1.3f,
                center = center
            )

            // Middle neon ring
            drawCircle(
                brush = Brush.sweepGradient(
                    colors = listOf(NeonCyan, NeonPurple, ElectricBlue, NeonCyan),
                    center = center
                ),
                radius = baseRadius * pulseScale,
                center = center,
                style = Stroke(width = 3.dp.toPx())
            )

            // Core inner orb
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White, NeonCyan, Color(0xFF0F172A)),
                    center = center,
                    radius = baseRadius * 0.7f
                ),
                radius = baseRadius * 0.7f,
                center = center
            )
        }
    }
}
