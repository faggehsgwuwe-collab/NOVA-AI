package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MainViewModel
import com.example.NovaApp
import com.example.ui.components.NeonCard
import com.example.ui.theme.CardNavy
import com.example.ui.theme.CardNavyBorder
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val prefs = NovaApp.instance.preferences
    val scope = rememberCoroutineScope()

    var backendUrl by remember { mutableStateOf(prefs.backendUrl) }
    var geminiApiKey by remember { mutableStateOf(prefs.geminiApiKey) }
    var geminiModel by remember { mutableStateOf(prefs.geminiModel) }
    var selectedLanguage by remember { mutableStateOf(prefs.language) }
    var isTtsEnabled by remember { mutableStateOf(prefs.isTtsEnabled) }
    var ttsPitch by remember { mutableFloatStateOf(prefs.ttsPitch) }
    var ttsSpeed by remember { mutableFloatStateOf(prefs.ttsSpeed) }

    var showGuideDialog by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DeepNavy)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "⚙️ NOVA AI সেটিংস",
                color = NeonCyan,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Button(
                onClick = { showGuideDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("setup_guide_btn")
            ) {
                Icon(Icons.AutoMirrored.Filled.HelpOutline, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("সেটআপ গাইড", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        // 1. Secure Backend Proxy Settings (Recommended)
        NeonCard(borderColor = NeonCyan.copy(alpha = 0.5f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Cloud, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "নিরাপদ Backend Proxy URL (প্রস্তাবিত)",
                    color = NeonCyan,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "আপনার API Key সরাসরি APK-তে না রেখে নিজস্ব Cloudflare Worker বা Firebase Backend-এর মাধ্যমে নিরাপদে ব্যবহার করুন।",
                color = TextSecondary,
                fontSize = 11.sp,
                lineHeight = 16.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = backendUrl,
                onValueChange = {
                    backendUrl = it
                    prefs.backendUrl = it
                },
                placeholder = { Text("https://nova-ai-backend.yourname.workers.dev/api/chat", color = TextMuted, fontSize = 12.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonCyan,
                    unfocusedBorderColor = CardNavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("backend_url_input")
            )

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Button(
                    onClick = {
                        if (backendUrl.isBlank()) {
                            Toast.makeText(context, "অনুগ্রহ করে Backend URL প্রবেশ করান", Toast.LENGTH_SHORT).show()
                        } else {
                            scope.launch {
                                val res = NovaApp.instance.geminiApiClient.sendMessage("Hello NOVA, test connection")
                                if (res.isSuccess) {
                                    Toast.makeText(context, "সংযুক্ত হয়েছে! সফল উত্তর পাওয়া গেছে ✅", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "ব্যর্থ: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CardNavy),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("সংযোগ পরীক্ষা করুন", color = NeonCyan, fontSize = 11.sp)
                }
            }
        }

        // 2. Direct Gemini API Key (Alternative for testing)
        NeonCard(borderColor = ElectricBlue.copy(alpha = 0.4f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Key, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "সরাসরি Gemini API Key (বিকল্প)",
                    color = ElectricBlue,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Backend তৈরি করার আগে সরাসরি টেস্ট করার জন্য Google AI Studio থেকে ফ্রি কী বসাতে পারেন:",
                color = TextSecondary,
                fontSize = 11.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = geminiApiKey,
                onValueChange = {
                    geminiApiKey = it
                    prefs.geminiApiKey = it
                },
                placeholder = { Text("AIzaSy...", color = TextMuted, fontSize = 12.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = CardNavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("gemini_api_key_input")
            )

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "🔗 aistudio.google.com থেকে বিনামূল্যে API Key নিন",
                color = NeonCyan,
                fontSize = 11.sp,
                modifier = Modifier.clickable {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/app/apikey"))
                    context.startActivity(intent)
                }
            )
        }

        // 3. AI Model Selector
        NeonCard(borderColor = NeonPurple.copy(alpha = 0.4f)) {
            Text(
                text = "🤖 AI মডেল নির্বাচন",
                color = NeonPurple,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            val models = listOf("gemini-3.8-flash", "gemini-flash-latest")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                models.forEach { modelName ->
                    val isSelected = geminiModel == modelName
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) NeonPurple else CardNavy)
                            .border(1.dp, if (isSelected) NeonPurple else CardNavyBorder, RoundedCornerShape(8.dp))
                            .clickable {
                                geminiModel = modelName
                                prefs.geminiModel = modelName
                            }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = modelName,
                            color = if (isSelected) Color.White else TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }

        // 4. Language & Voice Settings
        NeonCard(borderColor = NeonGreen.copy(alpha = 0.4f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Language, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "ভাষা ও ভয়েস আউটপুট",
                    color = NeonGreen,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(10.dp))

            // Language Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("সহকারীর ভাষা:", color = TextPrimary, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val isBn = selectedLanguage == "bn"
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isBn) NeonGreen else CardNavy)
                            .clickable {
                                selectedLanguage = "bn"
                                prefs.language = "bn"
                                viewModel.updateTtsLanguage()
                            }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text("বাংলা", color = if (isBn) DeepNavy else TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    val isEn = selectedLanguage == "en"
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isEn) NeonGreen else CardNavy)
                            .clickable {
                                selectedLanguage = "en"
                                prefs.language = "en"
                                viewModel.updateTtsLanguage()
                            }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text("English", color = if (isEn) DeepNavy else TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // TTS Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("ভয়েস আউটপুট (TTS স্পিচ):", color = TextPrimary, fontSize = 13.sp)
                Switch(
                    checked = isTtsEnabled,
                    onCheckedChange = {
                        isTtsEnabled = it
                        prefs.isTtsEnabled = it
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = DeepNavy,
                        checkedTrackColor = NeonGreen
                    )
                )
            }

            if (isTtsEnabled) {
                Spacer(modifier = Modifier.height(10.dp))
                Text("ভয়েস পিচ: ${(ttsPitch * 10).toInt() / 10f}", color = TextSecondary, fontSize = 11.sp)
                Slider(
                    value = ttsPitch,
                    onValueChange = {
                        ttsPitch = it
                        prefs.ttsPitch = it
                        viewModel.updateTtsLanguage()
                    },
                    valueRange = 0.5f..1.5f,
                    colors = SliderDefaults.colors(thumbColor = NeonGreen, activeTrackColor = NeonGreen)
                )

                Text("ভয়েস স্পিড: ${(ttsSpeed * 10).toInt() / 10f}", color = TextSecondary, fontSize = 11.sp)
                Slider(
                    value = ttsSpeed,
                    onValueChange = {
                        ttsSpeed = it
                        prefs.ttsSpeed = it
                        viewModel.updateTtsLanguage()
                    },
                    valueRange = 0.5f..1.5f,
                    colors = SliderDefaults.colors(thumbColor = NeonGreen, activeTrackColor = NeonGreen)
                )
            }
        }

        // 5. Android Permissions Overview
        NeonCard(borderColor = CardNavyBorder) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Security, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "অনুমতি ও নিরাপত্তা ব্যবস্থাপনা",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "• মাইক্রোফোন: ভয়েস ইনপুটের জন্য\n• অন্যান্য অ্যাপের ওপর প্রদর্শন: ভাসমান উইন্ডোর জন্য\n• অ্যাক্সেসিবিলিটি: ভয়েস নির্দেশনায় অ্যাপ কন্ট্রোলের জন্য\n• নোটিফিকেশন: Auto-Talk ও রিমাইন্ডারের জন্য",
                color = TextSecondary,
                fontSize = 11.sp,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = {
                    NovaApp.instance.phoneTools.openOverlaySettings()
                },
                colors = ButtonDefaults.buttonColors(containerColor = CardNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, CardNavyBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("ভাসমান উইন্ডো (Overlay) অনুমতি সেটিংস খুলুন", color = NeonCyan, fontSize = 12.sp)
            }
        }
    }

    if (showGuideDialog) {
        AlertDialog(
            onDismissRequest = { showGuideDialog = false },
            title = {
                Text("🚀 NOVA AI সম্পূর্ণ সেটআপ গাইড", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                val dialogScroll = rememberScrollState()
                Column(
                    modifier = Modifier
                        .verticalScroll(dialogScroll)
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        "১. Google AI Studio থেকে ফ্রি API Key সংগ্রহ:\n• aistudio.google.com-এ যান\n• 'Get API key' চেপে নতুন কী তৈরি করুন (সম্পূর্ণ বিনামূল্যে)।",
                        color = TextPrimary,
                        fontSize = 12.sp
                    )
                    Text(
                        "২. ফ্রি Cloudflare Worker Backend ডিপ্লয় (সম্পূর্ণ ফ্রি, ক্রেডিট কার্ড লাগে না):\n• dash.cloudflare.com-এ ফ্রি একাউন্ট খুলুন\n• 'Workers & Pages' > 'Create Worker' নির্বাচন করুন\n• এই প্রজেক্টের backend/index.js কোডটি পেস্ট করুন\n• Worker-এর Settings > Variables-এ Secret হিসেবে GEMINI_API_KEY যুক্ত করুন\n• প্রাপ্ত Worker URL (যেমন: https://nova-ai-backend.workers.dev/api/chat) এই অ্যাপের Settings-এ বসান।",
                        color = TextPrimary,
                        fontSize = 12.sp
                    )
                    Text(
                        "৩. GitHub Actions দিয়ে APK তৈরি:\n• GitHub-এ আপনার রিপোজিটরিতে কোড পুশ করুন\n• 'Actions' ট্যাবে যান\n• 'Build NOVA AI Android APK' স্বয়ংক্রিয়ভাবে চলবে এবং কিছুক্ষণের মধ্যে Artifacts-এ ইনস্টলযোগ্য APK ডাউনলোড করার লিঙ্ক পেয়ে যাবেন!",
                        color = TextPrimary,
                        fontSize = 12.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showGuideDialog = false }) {
                    Text("বুঝেছি", color = NeonCyan)
                }
            },
            containerColor = CardNavy,
            shape = RoundedCornerShape(16.dp)
        )
    }
}
