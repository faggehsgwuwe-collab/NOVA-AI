package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Games
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.MainViewModel
import com.example.NovaApp
import com.example.service.NovaAccessibilityService
import com.example.ui.components.NeonCard
import com.example.ui.theme.CardNavy
import com.example.ui.theme.CardNavyBorder
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ToolsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val phoneTools = NovaApp.instance.phoneTools

    val isFlashlightOn by viewModel.isFlashlightOn.collectAsStateWithLifecycle()
    val batteryText by viewModel.batteryText.collectAsStateWithLifecycle()
    val networkText by viewModel.networkText.collectAsStateWithLifecycle()
    val isFloatingRunning by viewModel.isFloatingRunning.collectAsStateWithLifecycle()
    val isAccessibilityEnabled by viewModel.isAccessibilityEnabled.collectAsStateWithLifecycle()

    var reminderMinutes by remember { mutableStateOf("10") }
    var reminderText by remember { mutableStateOf("") }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DeepNavy)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "🛠️ ডিভাইস কন্ট্রোল ও টুলস",
            color = NeonCyan,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "NOVA AI অনুমোদিত অ্যান্ড্রয়েড এপিআই দিয়ে সরাসরি আপনার ডিভাইস নিয়ন্ত্রণ করতে পারে।",
            color = TextSecondary,
            fontSize = 12.sp
        )

        // 1. Quick Control Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ToolTile(
                title = "ফ্ল্যাশলাইট",
                status = if (isFlashlightOn) "চালু" else "বন্ধ",
                icon = Icons.Default.FlashlightOn,
                isActive = isFlashlightOn,
                activeColor = NeonCyan,
                modifier = Modifier
                    .weight(1f)
                    .testTag("tool_flashlight_tile"),
                onClick = { viewModel.toggleFlashlight() }
            )

            ToolTile(
                title = "ভাসমান সহকারী",
                status = if (isFloatingRunning) "চালু" else "বন্ধ",
                icon = Icons.Default.OpenInBrowser,
                isActive = isFloatingRunning,
                activeColor = NeonPurple,
                modifier = Modifier
                    .weight(1f)
                    .testTag("tool_floating_tile"),
                onClick = {
                    val ok = viewModel.toggleFloatingService()
                    if (ok && !android.provider.Settings.canDrawOverlays(context)) {
                        phoneTools.openOverlaySettings()
                        Toast.makeText(context, "অনুগ্রহ করে Display over other apps অনুমতি দিন", Toast.LENGTH_LONG).show()
                    }
                }
            )
        }

        // 2. System Status Card
        NeonCard(borderColor = ElectricBlue.copy(alpha = 0.4f)) {
            Text(
                text = "📊 সিস্টেম স্ট্যাটাস",
                color = ElectricBlue,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.BatteryFull, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = batteryText, color = TextPrimary, fontSize = 13.sp)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Wifi, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = networkText, color = TextPrimary, fontSize = 13.sp)
            }

            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { phoneTools.openWifiSettings() },
                    colors = ButtonDefaults.buttonColors(containerColor = CardNavy),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardNavyBorder),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Wi-Fi সেটিংস", color = NeonCyan, fontSize = 11.sp)
                }

                Button(
                    onClick = { phoneTools.openBluetoothSettings() },
                    colors = ButtonDefaults.buttonColors(containerColor = CardNavy),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardNavyBorder),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("ব্লুটুথ সেটিংস", color = ElectricBlue, fontSize = 11.sp)
                }
            }
        }

        // 3. Quick Game & App Launchers
        NeonCard(borderColor = NeonPurple.copy(alpha = 0.4f)) {
            Text(
                text = "🎮 গেম ও অ্যাপস লঞ্চার",
                color = NeonPurple,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "ভয়েস কমান্ড বা এক ট্যাপে যেকোনো অ্যাপ খুলুন:",
                color = TextSecondary,
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        val res = phoneTools.launchAppByName("free fire")
                        Toast.makeText(context, res, Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("launch_freefire_btn")
                ) {
                    Icon(Icons.Default.Games, contentDescription = null, tint = DeepNavy, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Free Fire", color = DeepNavy, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                Button(
                    onClick = {
                        val res = phoneTools.launchAppByName("whatsapp")
                        Toast.makeText(context, res, Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("WhatsApp", color = DeepNavy, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                Button(
                    onClick = {
                        val res = phoneTools.launchAppByName("youtube")
                        Toast.makeText(context, res, Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPink),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("YouTube", color = DeepNavy, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        // 4. Accessibility Service Automation Controller
        NeonCard(borderColor = if (isAccessibilityEnabled) NeonGreen.copy(alpha = 0.4f) else NeonPink.copy(alpha = 0.4f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AccessibilityNew,
                        contentDescription = null,
                        tint = if (isAccessibilityEnabled) NeonGreen else NeonPink,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "অ্যাক্সেসিবিলিটি সার্ভিস",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isAccessibilityEnabled) NeonGreen.copy(alpha = 0.2f) else NeonPink.copy(alpha = 0.2f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isAccessibilityEnabled) "চালু আছে ✅" else "অনুমতি প্রয়োজন ⚠️",
                        color = if (isAccessibilityEnabled) NeonGreen else NeonPink,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "অ্যাক্সেসিবিলিটি সার্ভিসের মাধ্যমে NOVA AI আপনার নির্দেশনায় ব্যাক বাটন, হোম বাটন অথবা নির্দিষ্ট অ্যাপ নেভিগেশন করতে পারে। এটি সম্পূর্ণ নিরাপদ ও স্বচ্ছ।",
                color = TextSecondary,
                fontSize = 12.sp,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(10.dp))
            if (isAccessibilityEnabled) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            val ok = NovaAccessibilityService.instance?.triggerBack() ?: false
                            Toast.makeText(context, if (ok) "Back অ্যাকশন কার্যকর" else "ব্যর্থ", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CardNavy),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CardNavyBorder),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Back", color = NeonCyan, fontSize = 11.sp)
                    }

                    Button(
                        onClick = {
                            val ok = NovaAccessibilityService.instance?.triggerHome() ?: false
                            Toast.makeText(context, if (ok) "Home অ্যাকশন কার্যকর" else "ব্যর্থ", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CardNavy),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CardNavyBorder),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Home", color = NeonCyan, fontSize = 11.sp)
                    }

                    Button(
                        onClick = {
                            val summary = NovaAccessibilityService.instance?.readCurrentScreenSummary() ?: "সার্ভিস সক্রিয় নয়"
                            Toast.makeText(context, summary, Toast.LENGTH_LONG).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CardNavy),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CardNavyBorder),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("স্ক্রিন পড়ুন", color = NeonCyan, fontSize = 11.sp)
                    }
                }
            } else {
                Button(
                    onClick = { phoneTools.openAccessibilitySettings() },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPink),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("enable_accessibility_btn")
                ) {
                    Text("অ্যাক্সেসিবিলিটি সেটিংস খুলুন ও চালু করুন", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        // 5. Quick Reminder Creator
        NeonCard(borderColor = NeonCyan.copy(alpha = 0.4f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Alarm, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "⏰ কাস্টম রিমাইন্ডার তৈরি করুন",
                    color = NeonCyan,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = reminderText,
                onValueChange = { reminderText = it },
                label = { Text("কী মনে করিয়ে দিতে হবে? (যেমন: ওষুধ খাওয়া)", color = TextMuted, fontSize = 12.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonCyan,
                    unfocusedBorderColor = CardNavyBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = reminderMinutes,
                    onValueChange = { reminderMinutes = it.filter { ch -> ch.isDigit() } },
                    label = { Text("কত মিনিট পর?", color = TextMuted, fontSize = 12.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = CardNavyBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.width(130.dp)
                )

                Spacer(modifier = Modifier.width(10.dp))

                Button(
                    onClick = {
                        val mins = reminderMinutes.toIntOrNull() ?: 10
                        val text = reminderText.ifBlank { "নির্ধারিত কাজ সম্পূর্ণ করুন" }
                        val ok = phoneTools.scheduleReminder(text, mins)
                        if (ok) {
                            Toast.makeText(context, "$mins মিনিট পর রিমাইন্ডার সেট হয়েছে! ⏰", Toast.LENGTH_SHORT).show()
                            reminderText = ""
                        } else {
                            Toast.makeText(context, "রিমাইন্ডার সেট করা যায়নি", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("set_reminder_btn")
                ) {
                    Text("সেট করুন", color = DeepNavy, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ToolTile(
    title: String,
    status: String,
    icon: ImageVector,
    isActive: Boolean,
    activeColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .border(1.dp, if (isActive) activeColor else CardNavyBorder, RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = CardNavy),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isActive) activeColor else TextMuted,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(text = title, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(text = status, color = if (isActive) activeColor else TextMuted, fontSize = 12.sp)
        }
    }
}
