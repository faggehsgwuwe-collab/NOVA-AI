package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.provider.Settings
import android.text.TextUtils
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class NovaAccessibilityService : AccessibilityService() {

    companion object {
        var instance: NovaAccessibilityService? = null
            private set

        fun isServiceRunning(context: Context): Boolean {
            val expectedServiceName = "${context.packageName}/${NovaAccessibilityService::class.java.canonicalName}"
            val enabledServicesSetting = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false

            val colonSplitter = TextUtils.SimpleStringSplitter(':')
            colonSplitter.setString(enabledServicesSetting)

            while (colonSplitter.hasNext()) {
                val componentNameString = colonSplitter.next()
                if (componentNameString.equals(expectedServiceName, ignoreCase = true)) {
                    return true
                }
            }
            return false
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        val info = serviceInfo ?: AccessibilityServiceInfo()
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
        info.notificationTimeout = 100
        info.flags = info.flags or AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        serviceInfo = info
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Safe passive event listener
    }

    override fun onInterrupt() {
        // Handle interruption
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) {
            instance = null
        }
    }

    fun triggerBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun triggerHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun triggerRecentApps(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun triggerNotifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun readCurrentScreenSummary(): String {
        val rootNode = rootInActiveWindow ?: return "বর্তমান স্ক্রিনের কন্টেন্ট পড়া যাচ্ছে না।"
        val textList = mutableListOf<String>()
        collectNodeTexts(rootNode, textList)
        return if (textList.isEmpty()) {
            "স্ক্রিনে কোনো দৃশ্যমান লেখা পাওয়া যায়নি।"
        } else {
            textList.take(5).joinToString("\n• ", prefix = "স্ক্রিনের মূল বিষয়বস্তু:\n• ")
        }
    }

    private fun collectNodeTexts(node: AccessibilityNodeInfo, output: MutableList<String>) {
        val text = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()
        if (!text.isNullOrEmpty() && text.length > 2 && !output.contains(text)) {
            output.add(text)
        } else if (!desc.isNullOrEmpty() && desc.length > 2 && !output.contains(desc)) {
            output.add(desc)
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectNodeTexts(child, output)
        }
    }
}
