package com.example.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.NovaApp
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

class AutoTalkService : Service(), TextToSpeech.OnInitListener {

    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var job: Job? = null
    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    companion object {
        const val ACTION_START = "action_start_auto_talk"
        const val ACTION_STOP = "action_stop_auto_talk"

        var isRunning = false
            private set
    }

    private val bengaliCheckIns = listOf(
        "হ্যালো! আপনার দিনটি কেমন কাটছে? কোনো সাহায্য লাগলে আমাকে বলুন।",
        "একটু বিরতি নেওয়ার সময় হয়েছে! চোখে আরাম দিন এবং পানি পান করুন।",
        "আজকের কোনো গুরুত্বপূর্ণ রিমাইন্ডার বা কাজ বাকি আছে কি?",
        "আপনার ফোনে কোনো সমস্যা বা সেটিংস পরিবর্তনের প্রয়োজন হলে আমাকে জানাতে পারেন।",
        "Free Fire বা প্রিয় কোনো গেমে নতুন ট্রিক ও টিপস জানতে চাইলে আমাকে বলুন!",
        "আমি NOVA AI, সবসময় আপনার ডিজিটাল সঙ্গী হিসেবে প্রস্তুত আছি।"
    )

    private val englishCheckIns = listOf(
        "Hello! Just checking in. How is your day going?",
        "Time for a quick break! Rest your eyes and stay hydrated.",
        "Do you have any tasks or reminders you'd like me to set for you?",
        "Need help with coding, translation, or general questions? Ask me anytime!",
        "Ready to game or work? I'm right here if you need assistance."
    )

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        tts = TextToSpeech(this, this)
        startForeground(1002, buildNotification("NOVA AI Auto-Talk সক্রিয়"))
        startAutoTalkLoop()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            val lang = if (NovaApp.instance.preferences.language == "bn") Locale("bn", "BD") else Locale.US
            tts?.language = lang
            tts?.setPitch(NovaApp.instance.preferences.ttsPitch)
            tts?.setSpeechRate(NovaApp.instance.preferences.ttsSpeed)
        }
    }

    private fun startAutoTalkLoop() {
        job?.cancel()
        job = serviceScope.launch {
            while (isActive) {
                val intervalMinutes = NovaApp.instance.preferences.autoTalkIntervalMinutes.coerceAtLeast(1)
                val delayMs = intervalMinutes * 60 * 1000L
                delay(delayMs)

                if (!isActive) break

                val isBengali = NovaApp.instance.preferences.language == "bn"
                val phrases = if (isBengali) bengaliCheckIns else englishCheckIns
                val message = phrases.random()

                // Speak via TTS
                if (isTtsReady && NovaApp.instance.preferences.isTtsEnabled) {
                    tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "nova_auto_talk")
                }

                // Update notification
                updateNotification(message)
            }
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, AutoTalkService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 2, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val interval = NovaApp.instance.preferences.autoTalkIntervalMinutes

        return NotificationCompat.Builder(this, NovaApp.CHANNEL_AUTO_TALK_ID)
            .setContentTitle("🗣️ NOVA AI Auto-Talk ($interval মিনিট অন্তর)")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "বন্ধ করুন", stopPendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        try {
            val notification = buildNotification(text)
            NotificationManagerCompat.from(this).notify(1002, notification)
        } catch (e: SecurityException) {
            // Notification permission might be restricted
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        job?.cancel()
        serviceScope.cancel()
        tts?.stop()
        tts?.shutdown()
    }
}
