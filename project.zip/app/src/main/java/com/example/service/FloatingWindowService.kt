package com.example.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.NovaApp
import com.example.R
import com.example.data.local.ChatMessage
import com.example.tools.CommandResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class FloatingWindowService : Service(), TextToSpeech.OnInitListener {

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var windowManager: WindowManager

    private var floatingView: View? = null
    private var miniOrbView: View? = null
    private var expandedCardView: View? = null

    private var responseTextView: TextView? = null
    private var inputEditText: EditText? = null
    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    private lateinit var params: WindowManager.LayoutParams
    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var isExpanded = false

    companion object {
        const val ACTION_START = "action_start_floating"
        const val ACTION_STOP = "action_stop_floating"

        var isRunning = false
            private set
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        startForeground(1001, createNotification())
        createFloatingOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            val lang = if (NovaApp.instance.preferences.language == "bn") Locale("bn", "BD") else Locale.US
            tts?.language = lang
            tts?.setPitch(NovaApp.instance.preferences.ttsPitch)
            tts?.setSpeechRate(NovaApp.instance.preferences.ttsSpeed)
        }
    }

    private fun speak(text: String) {
        if (!NovaApp.instance.preferences.isTtsEnabled || !isTtsReady) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nova_floating_tts")
    }

    private fun createNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, FloatingWindowService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, NovaApp.CHANNEL_FLOATING_ID)
            .setContentTitle("NOVA AI Floating Assistant")
            .setContentText("স্ক্রিনের ওপর ভাসমান সহকারী সক্রিয় আছে")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "বন্ধ করুন", stopPendingIntent)
            .setOngoing(true)
            .build()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createFloatingOverlay() {
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 200
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        // 1. Mini Draggable Orb (Visible by default)
        miniOrbView = createMiniOrbView()

        // 2. Expanded Card (Hidden initially)
        expandedCardView = createExpandedCardView()
        expandedCardView?.visibility = View.GONE

        container.addView(miniOrbView)
        container.addView(expandedCardView)

        floatingView = container

        // Touch listener for dragging Mini Orb
        miniOrbView?.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(floatingView, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val diffX = Math.abs(event.rawX - initialTouchX)
                    val diffY = Math.abs(event.rawY - initialTouchY)
                    if (diffX < 15 && diffY < 15) {
                        toggleExpand()
                    }
                    true
                }
                else -> false
            }
        }

        try {
            windowManager.addView(floatingView, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun createMiniOrbView(): View {
        val orbLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            val sizePx = (56 * resources.displayMetrics.density).toInt()
            layoutParams = LinearLayout.LayoutParams(sizePx, sizePx)

            val bg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#0B101D"))
                setStroke((2 * resources.displayMetrics.density).toInt(), Color.parseColor("#00E5FF"))
            }
            background = bg
            elevation = 12f
        }

        val icon = ImageView(this).apply {
            setImageResource(R.drawable.ic_nova_logo)
            val iconSize = (40 * resources.displayMetrics.density).toInt()
            layoutParams = LinearLayout.LayoutParams(iconSize, iconSize).apply {
                gravity = Gravity.CENTER
            }
        }
        orbLayout.addView(icon)
        return orbLayout
    }

    private fun createExpandedCardView(): View {
        val density = resources.displayMetrics.density
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val widthPx = (320 * density).toInt()
            layoutParams = LinearLayout.LayoutParams(widthPx, LinearLayout.LayoutParams.WRAP_CONTENT)
            setPadding((12 * density).toInt(), (12 * density).toInt(), (12 * density).toInt(), (12 * density).toInt())

            val bg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 16 * density
                setColor(Color.parseColor("#0B101D"))
                setStroke((2 * density).toInt(), Color.parseColor("#A855F7"))
            }
            background = bg
            elevation = 16f
        }

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val title = TextView(this).apply {
            text = "⚡ NOVA AI ASSISTANT"
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val btnMinimize = TextView(this).apply {
            text = " ━ "
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(8, 4, 8, 4)
            setOnClickListener { toggleExpand() }
        }

        val btnClose = TextView(this).apply {
            text = " ✕ "
            setTextColor(Color.parseColor("#F43F5E"))
            textSize = 16f
            setPadding(8, 4, 8, 4)
            setOnClickListener { stopSelf() }
        }

        header.addView(title)
        header.addView(btnMinimize)
        header.addView(btnClose)
        card.addView(header)

        // Action chips row
        val chipsScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = (8 * density).toInt()
                bottomMargin = (8 * density).toInt()
            }
        }

        val chipsLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        addChip(chipsLayout, "💡 Flashlight") { executeCommand("ফ্ল্যাশলাইট") }
        addChip(chipsLayout, "🔋 Battery") { executeCommand("ব্যাটারি") }
        addChip(chipsLayout, "🎮 Free Fire") { executeCommand("Free Fire খোলো") }
        addChip(chipsLayout, "📶 Network") { executeCommand("ইন্টারনেট অবস্থা") }
        chipsScroll.addView(chipsLayout)
        card.addView(chipsScroll)

        // Response container
        val scrollView = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (140 * density).toInt()
            )
            val scrollBg = GradientDrawable().apply {
                setColor(Color.parseColor("#111827"))
                cornerRadius = 8 * density
                setStroke(1, Color.parseColor("#1E293B"))
            }
            background = scrollBg
            setPadding((8 * density).toInt(), (8 * density).toInt(), (8 * density).toInt(), (8 * density).toInt())
        }

        responseTextView = TextView(this).apply {
            text = "স্বাগতম! আমি NOVA AI। আমি গেম বা অন্য কোনো অ্যাপের ওপরেও আপনাকে সাহায্য করতে প্রস্তুত।"
            setTextColor(Color.parseColor("#F8FAFC"))
            textSize = 13f
        }
        scrollView.addView(responseTextView)
        card.addView(scrollView)

        // Input row
        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = (8 * density).toInt()
            }
        }

        inputEditText = EditText(this).apply {
            hint = "কী করতে হবে বলুন..."
            setHintTextColor(Color.parseColor("#64748B"))
            setTextColor(Color.WHITE)
            textSize = 13f
            val editBg = GradientDrawable().apply {
                setColor(Color.parseColor("#162032"))
                cornerRadius = 8 * density
                setStroke(1, Color.parseColor("#00E5FF"))
            }
            background = editBg
            setPadding((8 * density).toInt(), (6 * density).toInt(), (8 * density).toInt(), (6 * density).toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) {
                    // Make window focusable so keyboard appears
                    params.flags = WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                    windowManager.updateViewLayout(floatingView, params)
                }
            }
        }

        val btnSend = Button(this).apply {
            text = "পাঠান"
            textSize = 12f
            setTextColor(Color.parseColor("#070B14"))
            val btnBg = GradientDrawable().apply {
                setColor(Color.parseColor("#00E5FF"))
                cornerRadius = 8 * density
            }
            background = btnBg
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                (36 * density).toInt()
            ).apply {
                marginStart = (6 * density).toInt()
            }
            setOnClickListener {
                val query = inputEditText?.text?.toString()?.trim() ?: ""
                if (query.isNotEmpty()) {
                    inputEditText?.setText("")
                    executeCommand(query)
                }
            }
        }

        inputRow.addView(inputEditText)
        inputRow.addView(btnSend)
        card.addView(inputRow)

        return card
    }

    private fun addChip(layout: LinearLayout, label: String, onClick: () -> Unit) {
        val density = resources.displayMetrics.density
        val chip = TextView(this).apply {
            text = label
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 11f
            val chipBg = GradientDrawable().apply {
                setColor(Color.parseColor("#162032"))
                cornerRadius = 12 * density
                setStroke(1, Color.parseColor("#1E293B"))
            }
            background = chipBg
            setPadding((10 * density).toInt(), (4 * density).toInt(), (10 * density).toInt(), (4 * density).toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginEnd = (6 * density).toInt()
            }
            setOnClickListener { onClick() }
        }
        layout.addView(chip)
    }

    private fun toggleExpand() {
        isExpanded = !isExpanded
        if (isExpanded) {
            miniOrbView?.visibility = View.GONE
            expandedCardView?.visibility = View.VISIBLE
        } else {
            expandedCardView?.visibility = View.GONE
            miniOrbView?.visibility = View.VISIBLE
            // Remove keyboard focus
            params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            windowManager.updateViewLayout(floatingView, params)
        }
    }

    private fun executeCommand(input: String) {
        responseTextView?.text = "ভাবছি..."

        serviceScope.launch {
            // First check if it's a hardware/device action
            val commandResult = NovaApp.instance.voiceCommander.processCommand(input)
            when (commandResult) {
                is CommandResult.Executed -> {
                    responseTextView?.text = commandResult.message
                    speak(commandResult.message)
                    NovaApp.instance.database.chatDao().insertMessage(
                        ChatMessage(sender = "user", text = input)
                    )
                    NovaApp.instance.database.chatDao().insertMessage(
                        ChatMessage(sender = "nova", text = commandResult.message)
                    )
                }
                is CommandResult.SendToAi -> {
                    val history = withContext(Dispatchers.IO) {
                        NovaApp.instance.database.chatDao().getRecentMessages(4)
                    }
                    val result = NovaApp.instance.geminiApiClient.sendMessage(input, history)
                    val reply = result.getOrElse { "ত্রুটি: ${it.message ?: "উত্তরে সমস্যা হয়েছে"}" }
                    responseTextView?.text = reply
                    speak(reply)

                    NovaApp.instance.database.chatDao().insertMessage(
                        ChatMessage(sender = "user", text = input)
                    )
                    NovaApp.instance.database.chatDao().insertMessage(
                        ChatMessage(sender = "nova", text = reply)
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        floatingView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        tts?.stop()
        tts?.shutdown()
        serviceScope.cancel()
    }
}
