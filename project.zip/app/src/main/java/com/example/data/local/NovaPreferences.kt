package com.example.data.local

import android.content.Context
import android.content.SharedPreferences

class NovaPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("nova_ai_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_BACKEND_URL = "backend_url"
        private const val KEY_GEMINI_API_KEY = "gemini_api_key"
        private const val KEY_GEMINI_MODEL = "gemini_model"
        private const val KEY_LANGUAGE = "language"
        private const val KEY_TTS_ENABLED = "tts_enabled"
        private const val KEY_TTS_PITCH = "tts_pitch"
        private const val KEY_TTS_SPEED = "tts_speed"
        private const val KEY_AUTO_TALK_ENABLED = "auto_talk_enabled"
        private const val KEY_AUTO_TALK_INTERVAL = "auto_talk_interval"
        private const val KEY_FLOATING_ENABLED = "floating_enabled"

        const val DEFAULT_MODEL = "gemini-3.8-flash"
        const val DEFAULT_LANGUAGE = "bn"
    }

    var backendUrl: String
        get() = prefs.getString(KEY_BACKEND_URL, "") ?: ""
        set(value) = prefs.edit().putString(KEY_BACKEND_URL, value.trim()).apply()

    var geminiApiKey: String
        get() = prefs.getString(KEY_GEMINI_API_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_GEMINI_API_KEY, value.trim()).apply()

    var geminiModel: String
        get() = prefs.getString(KEY_GEMINI_MODEL, DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(value) = prefs.edit().putString(KEY_GEMINI_MODEL, value.trim()).apply()

    var language: String
        get() = prefs.getString(KEY_LANGUAGE, DEFAULT_LANGUAGE) ?: DEFAULT_LANGUAGE
        set(value) = prefs.edit().putString(KEY_LANGUAGE, value).apply()

    var isTtsEnabled: Boolean
        get() = prefs.getBoolean(KEY_TTS_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_TTS_ENABLED, value).apply()

    var ttsPitch: Float
        get() = prefs.getFloat(KEY_TTS_PITCH, 1.25f)
        set(value) = prefs.edit().putFloat(KEY_TTS_PITCH, value).apply()

    var ttsSpeed: Float
        get() = prefs.getFloat(KEY_TTS_SPEED, 0.95f)
        set(value) = prefs.edit().putFloat(KEY_TTS_SPEED, value).apply()

    var isAutoTalkEnabled: Boolean
        get() = prefs.getBoolean(KEY_AUTO_TALK_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_TALK_ENABLED, value).apply()

    var autoTalkIntervalMinutes: Int
        get() = prefs.getInt(KEY_AUTO_TALK_INTERVAL, 15)
        set(value) = prefs.edit().putInt(KEY_AUTO_TALK_INTERVAL, value).apply()

    var isFloatingEnabled: Boolean
        get() = prefs.getBoolean(KEY_FLOATING_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_FLOATING_ENABLED, value).apply()
}
