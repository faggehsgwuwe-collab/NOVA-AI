package com.example.data.api

import android.content.Context
import com.example.BuildConfig
import com.example.data.local.ChatMessage
import com.example.data.local.NovaPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiApiClient(context: Context) {
    private val prefs = NovaPreferences(context)
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun sendMessage(
        userMessage: String,
        recentHistory: List<ChatMessage> = emptyList()
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val backendUrl = prefs.backendUrl.trim()
            val rawKey = prefs.geminiApiKey.trim().ifEmpty {
                try {
                    BuildConfig.GEMINI_API_KEY
                } catch (e: Exception) {
                    ""
                }
            }
            val directKey = if (rawKey == "MY_GEMINI_API_KEY") "" else rawKey

            // Path 1: User's Secure Backend Proxy (Cloudflare Worker / Firebase)
            if (backendUrl.isNotEmpty()) {
                return@withContext callBackendProxy(backendUrl, userMessage, recentHistory)
            }

            // Path 2: Direct Gemini API (if key is supplied in settings or BuildConfig)
            if (directKey.isNotEmpty()) {
                return@withContext callDirectGemini(directKey, userMessage, recentHistory)
            }

            // Path 3: Neither configured yet - return instructional response
            Result.success(
                "✨ NOVA AI সক্রিয়! \n\n" +
                "Gemini AI থেকে পূর্ণ উত্তর পেতে অনুগ্রহ করে Settings-এ যান:\n" +
                "১. আপনার নিজস্ব Cloudflare Worker Backend URL দিন (সবচেয়ে নিরাপদ), অথবা\n" +
                "২. Google AI Studio থেকে ফ্রি Gemini API Key প্রদান করুন।\n\n" +
                "ডিভাইস কন্ট্রোল ও ভয়েস কমান্ড (যেমন: Flashlight, Battery, Free Fire) এখনই কাজ করবে!"
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun callBackendProxy(
        url: String,
        userMessage: String,
        recentHistory: List<ChatMessage>
    ): Result<String> {
        val payload = JSONObject().apply {
            put("message", userMessage)
            put("language", prefs.language)
            put("model", prefs.geminiModel)

            val historyArray = JSONArray()
            recentHistory.takeLast(6).forEach { msg ->
                val item = JSONObject().apply {
                    put("role", if (msg.sender == "user") "user" else "model")
                    put("text", msg.text)
                }
                historyArray.put(item)
            }
            put("history", historyArray)
        }

        val request = Request.Builder()
            .url(url)
            .post(payload.toString().toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { response ->
            val body = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                return Result.failure(Exception("Backend Error HTTP ${response.code}: $body"))
            }

            return try {
                val json = JSONObject(body)
                val reply = when {
                    json.has("reply") -> json.getString("reply")
                    json.has("response") -> json.getString("response")
                    json.has("text") -> json.getString("text")
                    else -> body
                }
                Result.success(reply.trim())
            } catch (e: Exception) {
                Result.success(body.trim())
            }
        }
    }

    private fun callDirectGemini(
        apiKey: String,
        userMessage: String,
        recentHistory: List<ChatMessage>
    ): Result<String> {
        val savedModel = prefs.geminiModel
        val model = if (savedModel.isEmpty() || savedModel == "gemini-1.5-flash" || savedModel == "gemini-2.0-flash") NovaPreferences.DEFAULT_MODEL else savedModel
        val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"

        val systemPrompt = "You are NOVA AI, a highly intelligent, empathetic, and ultra-futuristic personal AI assistant for Android. " +
                "You are fluent in Bengali (বাংলা) and English. When addressed in Bengali, respond naturally in conversational, friendly Bengali. " +
                "You help with coding, phone automation, knowledge, daily tasks, gaming tips (like Free Fire), translations, and problem solving. " +
                "Keep responses engaging, clear, well-structured, and helpful."

        val contentsArray = JSONArray()

        // Include system prompt instructions in first turn
        val systemTurn = JSONObject().apply {
            put("role", "user")
            put("parts", JSONArray().put(JSONObject().put("text", "System Instruction: $systemPrompt")))
        }
        val systemAck = JSONObject().apply {
            put("role", "model")
            put("parts", JSONArray().put(JSONObject().put("text", "Understood. I am NOVA AI, ready to assist in Bengali and English.")))
        }
        contentsArray.put(systemTurn)
        contentsArray.put(systemAck)

        // Previous context
        recentHistory.takeLast(6).forEach { msg ->
            val turn = JSONObject().apply {
                put("role", if (msg.sender == "user") "user" else "model")
                put("parts", JSONArray().put(JSONObject().put("text", msg.text)))
            }
            contentsArray.put(turn)
        }

        // Current message
        contentsArray.put(JSONObject().apply {
            put("role", "user")
            put("parts", JSONArray().put(JSONObject().put("text", userMessage)))
        })

        val root = JSONObject().apply {
            put("contents", contentsArray)
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.7)
                put("maxOutputTokens", 2048)
            })
        }

        val request = Request.Builder()
            .url(endpoint)
            .post(root.toString().toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { response ->
            val body = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                val errorMsg = try {
                    val errJson = JSONObject(body)
                    errJson.optJSONObject("error")?.optString("message") ?: body
                } catch (e: Exception) {
                    body
                }
                return Result.failure(Exception("Gemini API Error (${response.code}): $errorMsg"))
            }

            val json = JSONObject(body)
            val candidates = json.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val first = candidates.getJSONObject(0)
                val content = first.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    val text = parts.getJSONObject(0).optString("text")
                    return Result.success(text.trim())
                }
            }
            return Result.failure(Exception("No content returned from Gemini API"))
        }
    }
}
