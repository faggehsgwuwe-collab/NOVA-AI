package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.example.data.api.GeminiApiClient
import com.example.data.local.AppDatabase
import com.example.data.local.NovaPreferences
import com.example.tools.PhoneToolsManager
import com.example.tools.VoiceCommander

class NovaApp : Application() {

    companion object {
        const val CHANNEL_FLOATING_ID = "nova_floating_channel"
        const val CHANNEL_AUTO_TALK_ID = "nova_auto_talk_channel"
        const val CHANNEL_REMINDERS_ID = "nova_reminders_channel"

        lateinit var instance: NovaApp
            private set
    }

    val database by lazy { AppDatabase.getDatabase(this) }
    val preferences by lazy { NovaPreferences(this) }
    val phoneTools by lazy { PhoneToolsManager(this) }
    val voiceCommander by lazy { VoiceCommander(phoneTools) }
    val geminiApiClient by lazy { GeminiApiClient(this) }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val floatingChannel = NotificationChannel(
                CHANNEL_FLOATING_ID,
                getString(R.string.channel_floating_service),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Foreground service notification for floating AI assistant"
            }

            val autoTalkChannel = NotificationChannel(
                CHANNEL_AUTO_TALK_ID,
                getString(R.string.channel_auto_talk),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Periodic proactive voice check-in notification"
            }

            val remindersChannel = NotificationChannel(
                CHANNEL_REMINDERS_ID,
                getString(R.string.channel_reminders),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Scheduled reminders and alerts"
                enableVibration(true)
            }

            manager.createNotificationChannel(floatingChannel)
            manager.createNotificationChannel(autoTalkChannel)
            manager.createNotificationChannel(remindersChannel)
        }
    }
}
